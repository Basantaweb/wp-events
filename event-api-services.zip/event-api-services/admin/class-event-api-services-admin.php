<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://github.com/Basantaweb/
 * @since      1.0.0
 *
 * @package    Event_Api_Services
 * @subpackage Event_Api_Services/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Event_Api_Services
 * @subpackage Event_Api_Services/admin
 * @author     BASANTA MANNA <basantamannanew@gmail.com>
 */
class Event_Api_Services_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * 
	*/
	public $table_name_events_list;
	public $table_name_events_category;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Event_Api_Services_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Event_Api_Services_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/event-api-services-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Event_Api_Services_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Event_Api_Services_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/event-api-services-admin.js', array( 'jquery' ), $this->version, false );

	}

	/**
	 * 
	*/

	public static function get_rest_route(){

		$endpoint = [	
			[
				"route"=>"list",
				"methods"=>"GET",
				"call_back"=>"get_events_list_data"
			],
			[
				"route"=>"create",
				"methods"=>"POST",
				"call_back"=>"get_events_create_data"
			],
			[
				"route"=>"update",
				"methods"=>"PUT",
				"call_back"=>"get_events_update_data"
			],
			[
				"route"=>"delete",
				"methods"=>"POST",
				"call_back"=>"get_events_delete_data"
			],
		];

		return $endpoint;

	}

	/**
	 * @var string $table_name_events_list
	 * @var string $table_name_events_category
	 * 
	*/

	public function custom_end_points(){

		global $wpdb;
		$this->table_name_events_list = $wpdb->prefix . 'events_list';
		$this->table_name_events_category = $wpdb->prefix . 'events_category';

		$get_endpoints = self::get_rest_route();

			foreach ($get_endpoints as $endpoint) {

				register_rest_route( 'events', $endpoint['route'], 
					[
						'methods' => $endpoint['methods'],
						'callback' => array( $this, $endpoint['call_back'] ),
						'permission_callback'=>[$this,"authenticateUser"],
					]
				);
			}
	}

	/**
	 * 
	*/

	public function get_events_list_data(WP_REST_Request $resData){

		global $wpdb;

		$this->table_name_events_list;
		$this->table_name_events_category;
		$get_data = $resData->get_params();

			if(!empty($_REQUEST['id'])){
				$sql = "SELECT
				el.`id` as id,  
				ec.`category_name` as category_name, 
				el.`title` as title, 
				el.`description` as description, 
				el.`start_date_time` as start_date_time, 
				el.`end_date_time` as end_date_time 
				FROM `wp_events_category` as ec,`wp_events_list` as el WHERE el.category = ec.id and el.id=".$_REQUEST['id'];
			}else{
				$sql = "SELECT 
				el.`id` as id,  
				ec.`category_name` as category_name, 
				el.`title` as title, 
				el.`description` as description, 
				el.`start_date_time` as start_date_time, 
				el.`end_date_time` as end_date_time 
				FROM `wp_events_category` as ec,`wp_events_list` as el WHERE el.category = ec.id";
			}	


		$result = $wpdb->get_results($sql);
		
		//print_r($result);
		return $result;
	}

	public function get_events_create_data(WP_REST_Request $resData){
		global $wpdb;
		$parameters = $resData->get_params(); 
		print_r($parameters);
		$title = $parameters['title'];
		$description = $parameters['description'];
		$category_name = $parameters['category_name'];
		$date = $parameters['date'];
	  
		   if($parameters) {
				if($category_name){
					$wpdb->insert($this->table_name_events_category, array(
						"category_name" => $category_name,
						"created_at" => $date,
					));
				}

				$cat_id = ($wpdb->insert_id)? $wpdb->insert_id:null;

			$update = $wpdb->insert($this->table_name_events_list, array(
					"title" => $title,
					"description" => $description,
					"category" => $cat_id,
					"start_date_time" => $date,
			  ));

			if($update) {
				return rest_ensure_response('Your message has been submit' );
				} else {
				return rest_ensure_response( 'Please complete form' );
			}
		   }
	}

	public function get_events_update_data(WP_REST_Request $resData){
		global $wpdb;
		$parameters = $resData->get_params(); 
		print_r($parameters);

		$title = $parameters['title'];
		$description = $parameters['description'];
		$category_name = $parameters['category_name'];
		$date = $parameters['date'];
		$id = $_REQUEST['id'];

		if(!empty($parameters) && !empty($id)) {
			
			$sql = "SELECT category FROM $this->table_name_events_list where id=".$id;
			$category_id = $wpdb->get_results($sql);
			$category_id = $category_id[0]->category;
			if($category_name){
				$wpdb->update($this->table_name_events_category, array(
					"category_name" => $category_name,
					"modified_at" => $date,
				), array(
					"id" => $category_id
				) );
			}

			$cat_id = ($category_id)? $category_id:null;

		$insert = $wpdb->update($this->table_name_events_list, array(
				"title" => $title,
				"description" => $description,
				"category" => $cat_id,
				"end_date_time" => $date,
		  	), array(
				"id" => $id
			));

		if($insert) {
			return rest_ensure_response(  'Your message has been updated' );
			} else {
			return rest_ensure_response( 'Please complete form' );
		}
	   }
	}

	public function get_events_delete_data(WP_REST_Request $resData){
		global $wpdb;
		$parameters = $resData->get_params(); 
		print_r($parameters);

		$id = $_REQUEST['id'];
		$sql = "SELECT category FROM $this->table_name_events_list where id=".$id;
		$category_id = $wpdb->get_results($sql);
		$category_id = $category_id[0]->category;


		$cat_del = $wpdb->delete( $this->table_name_events_category, [ 'id' => $category_id ] );
		if($cat_del){
			$events_del = $wpdb->delete( $this->table_name_events_list, [ 'id' => $id ] );
		}
		

		if($cat_del || $events_del) {
			return 'Category id=' . $category_id. 'and Events id='.$id.'Was deleted successfully ';
			} else {
			return 'Something wrong' ;
		}
	}


	public function authenticateUser( $request){
		if (!isset($_SERVER['PHP_AUTH_USER'])) {
			return $request;
		}
		$username = $_SERVER['PHP_AUTH_USER'];
		$is_email = strpos($username, '@');
		if ($is_email) {
			$ud = get_user_by_email($username);
			$username = $ud->user_login;
		}
		$password = $_SERVER['PHP_AUTH_PW'];
		$user = wp_authenticate($username, $password);

		if ( is_wp_error( $user ) ) {
			$wp_json_basic_auth_error = $user;
			return null;
		}
	
		$wp_json_basic_auth_error = true;
	
		return $user->ID;
	}

}
