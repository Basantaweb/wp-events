<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://github.com/Basantaweb/
 * @since      1.0.0
 *
 * @package    Event_Api_Services
 * @subpackage Event_Api_Services/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Event_Api_Services
 * @subpackage Event_Api_Services/includes
 * @author     BASANTA MANNA <basantamannanew@gmail.com>
 */
class Event_Api_Services_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
