<?php

/**
 * Fired during plugin activation
 *
 * @link       https://github.com/Basantaweb/
 * @since      1.0.0
 *
 * @package    Event_Api_Services
 * @subpackage Event_Api_Services/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Event_Api_Services
 * @subpackage Event_Api_Services/includes
 * @author     BASANTA MANNA <basantamannanew@gmail.com>
 */
class Event_Api_Services_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		self::events_create_db();
	}

	public static function events_create_db() {

		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();
		$table_name_events_list = $wpdb->prefix . 'events_list';
		$table_name_events_category = $wpdb->prefix . 'events_category';

		$sql_events_category = "CREATE TABLE IF NOT EXISTS $table_name_events_category (
			id mediumint(9) NOT NULL AUTO_INCREMENT,
			category_name text,
			created_at timestamp NOT NULL,
			modified_at timestamp NOT NULL,
			UNIQUE KEY id (id),
			PRIMARY KEY (id)
		) $charset_collate;";
		

		$sql_events_list = "CREATE TABLE IF NOT EXISTS $table_name_events_list (
			id mediumint(9) NOT NULL AUTO_INCREMENT,
			title text,
			description text,
			category mediumint(8) unsigned NOT NULL,
			start_date_time timestamp NOT NULL,
			end_date_time timestamp NOT NULL,
			UNIQUE KEY id (id),
			PRIMARY KEY (id),
			CONSTRAINT FK_events_category_id FOREIGN KEY (id) REFERENCES category (id) ON DELETE CASCADE ON UPDATE CASCADE
		) $charset_collate;";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql_events_list );
		dbDelta( $sql_events_category );
	}

}
